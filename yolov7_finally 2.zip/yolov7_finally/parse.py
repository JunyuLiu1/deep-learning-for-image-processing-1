from collections import defaultdict
import os, random
import numpy as np


# 统计所有的文件数目
def search_files(dir_path):
    result = []
    file_list = os.listdir(dir_path)
    for file_name in file_list:
        complete_file_name = os.path.join(dir_path, file_name)
        if os.path.isdir(complete_file_name):
            result.extend(search_files(complete_file_name))
        if os.path.isfile(complete_file_name):
            result.append(complete_file_name)

    return result


# 数据集切分
val_size = 0.2
sa, sb = os.sep + 'images' + os.sep, os.sep + 'labels' + os.sep

images_listdir = np.array(search_files('/media/user/fbd892e6-4e93-478c-b0be-c64f5d50c17d/jiaobo/yolov7/yolov7/datasets/datasets_1/images'))
random.shuffle(images_listdir)
train, val = images_listdir[:int(len(images_listdir) * (1 - val_size))], images_listdir[int(len(images_listdir) * (
        1 - val_size)):]
print(f'train set size:{len(train)} val set size:{len(val)}')

with open('./train1.txt', 'w') as f:
    for i in train:
        f.write(i)
        f.write('\n')

with open('./val1.txt', 'w') as f:
    for i in val:
        f.write(i)
        f.write('\n')

with open('./val1.txt', 'r') as f1:
    data = f1.read().replace('/media/user/fbd892e6-4e93-478c-b0be-c64f5d50c17d/jiaobo/yolov7/yolov7/datasets/datasets_1/labels', '.')
with open('./val1.txt', 'w') as f1:
    f1.write(data)

with open('./train1.txt', 'r') as f1:
    data = f1.read().replace('/media/user/fbd892e6-4e93-478c-b0be-c64f5d50c17d/jiaobo/yolov7/yolov7/datasets/datasets_1/labels', '.')
with open('./train1.txt', 'w') as f1:
    f1.write(data)


# 解析数据集切分后的文件数和标签类别个数
def parse_txt(txt_path):
    with open(txt_path, 'r') as f:
        file_list = f.readlines()
        print("共有文件：", len(file_list))

    mapping = defaultdict(int)
    for i in file_list:
        txt_file = 'txt'.join(i.replace(sa, sb, 1).rsplit(i.split('.')[-1], 1))
        # print(txt_file)
        with open(txt_file, 'r') as f:
            data_list = f.readlines()
            for item in data_list:
                cls = int(item.strip().split()[0])
                mapping[cls] += 1

    for k in sorted(mapping):
        print(k, mapping[k])


parse_txt('./val1.txt')